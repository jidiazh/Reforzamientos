"""Elimina ahora todos los elementos de la lista creada previamente y mostrar en
consola la lista actualizada agregando tu nombre, apellido paterno, apellido
materno y edad"""


# Lista inicial con elementos variados
mi_lista = [3.14, True, 9.81, False, 2.71, True, 6.28]

# Vaciar la lista
mi_lista.clear()

# Agregar nombre, apellidos y edad
mi_lista.append("Josue")
mi_lista.append("Diaz")
mi_lista.append("Hinostroza")
mi_lista.append(20)

# Mostrar la lista actualizada
print("Lista actualizada:", mi_lista)
